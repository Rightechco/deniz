// public/js/main.js

// این یک فایل جاوااسکریپت عمومی برای پروژه است.
// شما می‌توانید توابع و کدهای جاوااسکریپت مشترک خود را در اینجا قرار دهید.

document.addEventListener('DOMContentLoaded', function() {
    console.log('main.js loaded and DOM is ready.');

    // مثال: یک تابع ساده
    // function greetUser() {
    //     const header = document.querySelector('header h1 a');
    //     if (header) {
    //         // header.addEventListener('click', function(e) {
    //         //     e.preventDefault();
    //         //     alert('به فروشگاه من خوش آمدید!');
    //         // });
    //     }
    // }
    // greetUser();

    // کدهای مربوط به مدیریت تنوع محصول که در show.php بود،
    // اگر بخواهیم به اینجا منتقل شوند، نیاز به تغییراتی برای دسترسی به داده‌های PHP دارند.
    // فعلاً آنها را در همان ویو نگه می‌داریم تا از پیچیدگی جلوگیری شود.
});

// می‌توانید توابع دیگری را در اینجا تعریف کنید:
// function exampleFunction() {
//   // ...
// }
