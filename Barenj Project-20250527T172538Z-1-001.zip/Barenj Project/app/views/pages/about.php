<?php // ویو: app/views/pages/about.php ?>

<h1><?php echo htmlspecialchars($pageTitle); ?></h1>
<p><?php echo htmlspecialchars($description); ?></p>
<p><a href="<?php echo BASE_URL; ?>index.php?url=pages/index">بازگشت به صفحه اصلی</a></p>