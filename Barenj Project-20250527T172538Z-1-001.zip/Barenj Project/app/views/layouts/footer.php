    <?php // ویو: app/views/layouts/footer.php ?>

        </main> <?php // بستن تگ main از header.php ?>
    </div> <?php // بستن .container از header.php ?>

    <footer style="background-color: #333; color: white; text-align: center; padding: 20px 0; margin-top: 30px;">
        <p>&copy; <?php echo date('Y'); ?> فروشگاه شما. تمامی حقوق محفوظ است.</p>
    </footer>

    <script src="<?php echo BASE_URL; ?>js/jquery.min.js"></script> <script src="<?php echo BASE_URL; ?>js/kamadatepicker.min.js"></script>
    
    </body>
    </html>
    